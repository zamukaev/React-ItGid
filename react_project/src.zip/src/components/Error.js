function Error() {
	return (
		<>
			<div className="p-3 mb-2 bg-primary text-white mt-3 text-center">404 такой страницы не существует</div>


		</>
	);
}

export default Error;